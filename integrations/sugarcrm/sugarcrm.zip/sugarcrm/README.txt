Freshdesk for SugarCRM
----------------------
Please follow the instructions given in this solution article to setup and use the Freshdesk module for SugarCRM:
https://support.freshdesk.com/solution/categories/4/folders/15/articles/16982-integration-with-sugar-crm