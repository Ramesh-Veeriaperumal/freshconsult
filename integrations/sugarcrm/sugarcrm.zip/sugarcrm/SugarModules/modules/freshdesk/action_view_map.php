<?php

$action_view_map['ticketlist'] = 'ticketlist';
$action_view_map['settings'] = 'settings';