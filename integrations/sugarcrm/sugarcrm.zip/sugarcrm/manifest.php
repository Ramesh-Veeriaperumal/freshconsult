<?php

$manifest = array(
  'author' => 'Freshdesk', 'description' => 'Freshdesk for SugarCRM',
  'name' => 'Freshdesk',

  'acceptable_sugar_versions' => array('regex_matches' => array( '6\\.[12345]\\..*' )),
  'acceptable_sugar_flavors' => array('CE', 'PRO', 'CORP', 'ENT', 'ULT'),
  
  'key' => 'freshdesk',
  'type' => 'module',
  'icon' => '',
  'is_uninstallable' => true,
  
  'published_date' => '2012-07-18',
  'readme' => 'README.txt',
  'version' => '1.0',
);

$installdefs = array (
  'id' => 'freshdesk',
  'layoutdefs' => 
  array (
  ),
  'relationships' => 
  array (
  ),
  'image_dir' => '<basepath>/icons',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/freshdesk',
      'to' => 'modules/freshdesk',
    ),
    1 => array (
      'from' => '<basepath>/SugarModules/Extension',
      'to' => 'custom/Extension',
      ),
    ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/language/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
  ),
);

$upgrade_manifest = array (
  'upgrade_paths' =>
  array (  ),
);
